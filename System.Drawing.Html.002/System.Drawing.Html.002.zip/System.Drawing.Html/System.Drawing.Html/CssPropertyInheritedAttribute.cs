using System;
using System.Collections.Generic;
using System.Text;

namespace System.Drawing.Html
{
    public class CssPropertyInheritedAttribute : Attribute
    {
        public CssPropertyInheritedAttribute()
        {

        }
    }
}
